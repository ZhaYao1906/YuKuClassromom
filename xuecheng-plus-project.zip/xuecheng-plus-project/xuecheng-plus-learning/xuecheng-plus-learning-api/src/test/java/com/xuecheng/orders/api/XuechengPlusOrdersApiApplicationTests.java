package com.xuecheng.orders.api;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XuechengPlusOrdersApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
