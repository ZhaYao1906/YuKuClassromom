package com.xuecheng.checkcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XuechengPlusCheckcodeApplicationTests {

    @Test
    void contextLoads() {
    }

}
