package com.xuecheng.base.exception;

/**
 * @description 用于分级校验，定义一些常用的组
 */
public class ValidationGroups {
 public interface Inster{};
 public interface Update{};
 public interface Delete{};
}
