package com.xuecheng.content.service;

import com.xuecheng.content.model.po.CourseTeacher;

import java.util.List;

public interface CourseTeacherService {
    /**
     * 查询教师接口
     * @param id
     * @return
     */
    public List<CourseTeacher> queryCourseTeacherList(Long id);

    /**
     * 添加教师接口
     * @param courseTeacher
     * @return
     */
    public CourseTeacher saveCourseTeacher(CourseTeacher courseTeacher);

    /**
     * 删除课程老师
     * @param courseId
     * @param teacherId
     */
    public void deleteCourseTeacher(Long courseId,Long teacherId);
}
