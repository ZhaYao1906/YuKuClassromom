package com.xuecheng.content.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xuecheng.content.model.dto.TeachplanDto;
import com.xuecheng.content.model.po.Teachplan;

import java.util.List;

/**
 * 课程计划 Mapper 接口
 */
public interface TeachplanMapper extends BaseMapper<Teachplan> {
    //课程计划查询，明确是大章节和小章节，没必要用递归，可以直接使用表的自连接
    public List<TeachplanDto>  selectTreeNodes(Long courseId);
}
