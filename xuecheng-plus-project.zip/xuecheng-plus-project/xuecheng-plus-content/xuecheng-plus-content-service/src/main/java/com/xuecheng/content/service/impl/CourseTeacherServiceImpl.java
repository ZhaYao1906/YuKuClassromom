package com.xuecheng.content.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xuecheng.base.exception.XueChengPlusException;
import com.xuecheng.content.mapper.CourseTeacherMapper;
import com.xuecheng.content.model.po.CourseTeacher;
import com.xuecheng.content.service.CourseTeacherService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Slf4j
@Service
public class CourseTeacherServiceImpl implements CourseTeacherService{

    @Autowired
    private CourseTeacherMapper courseTeacherMapper;
    /**
     * 查询教师接口
     * @param id
     * @return
     */
    @Override
    public List<CourseTeacher> queryCourseTeacherList(Long id){
        LambdaQueryWrapper<CourseTeacher> qw = new LambdaQueryWrapper<>();
        qw.eq(CourseTeacher::getCourseId,id);
        return courseTeacherMapper.selectList(qw);
    }
    /**
     * 添加教师接口
     * @param courseTeacher
     * @return
     */
    @Override
    public CourseTeacher saveCourseTeacher(CourseTeacher courseTeacher){
        if(courseTeacher.getId() == null){
            //数据库中设计为课程id与教师姓名为唯一字段，要进行判断，不然会报错
            LambdaQueryWrapper<CourseTeacher> qw = new LambdaQueryWrapper<>();
            qw.eq(CourseTeacher::getCourseId,courseTeacher.getCourseId())
                    .eq(CourseTeacher::getTeacherName,courseTeacher.getTeacherName());
            CourseTeacher isCourseTeacher = courseTeacherMapper.selectOne(qw);
            if(isCourseTeacher != null) XueChengPlusException.cast("已有该教师！");
            //插入教师信息
            int insert = courseTeacherMapper.insert(courseTeacher);
            if(insert <= 0) XueChengPlusException.cast("保存教师信息失败！");
        }else{
            //更新教师信息
            int i = courseTeacherMapper.updateById(courseTeacher);
            if(i <= 0) XueChengPlusException.cast("更新教师失败！");
        }
        //最后结果要回显，所以添加教师接口最后要返回教师信息。
        return courseTeacherMapper.selectById(courseTeacher);
    }

    /**
     * 删除课程老师
     * @param courseId
     * @param teacherId
     */
    @Override
    public void deleteCourseTeacher(Long courseId,Long teacherId){
         LambdaQueryWrapper<CourseTeacher> qw = new LambdaQueryWrapper<>();
         qw.eq(CourseTeacher::getCourseId,courseId)
                 .eq(CourseTeacher::getId,teacherId);
         int delete = courseTeacherMapper.delete(qw);
         if(delete <= 0) XueChengPlusException.cast("删除教师失败");
    }
}
