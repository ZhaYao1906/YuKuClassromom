package com.xuecheng.content.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xuecheng.base.exception.XueChengPlusException;
import com.xuecheng.content.mapper.TeachplanMapper;
import com.xuecheng.content.mapper.TeachplanMediaMapper;
import com.xuecheng.content.model.dto.BindTeachplanMediaDto;
import com.xuecheng.content.model.dto.SaveTeachplanDto;
import com.xuecheng.content.model.dto.TeachplanDto;
import com.xuecheng.content.model.po.Teachplan;
import com.xuecheng.content.model.po.TeachplanMedia;
import com.xuecheng.content.service.TeachplanService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
public class TeachplanServiceImpl implements TeachplanService {

    @Autowired
    TeachplanMapper teachplanMapper;

    @Autowired
    TeachplanMediaMapper teachplanMediaMapper;
    /**
     * 根据课程id查询课程计划
     * @param courseId 课程id
     * @return
     */
    @Override
    public List<TeachplanDto> findTeachplanTree(Long courseId){
        List<TeachplanDto> teachplanDtos = teachplanMapper.selectTreeNodes(courseId);
        return teachplanDtos;
    }
    /**
     * 新增/修改/保存 课程计划
     * @param saveTeachplanDto
     */
    @Override
    public void saveTeachplan(SaveTeachplanDto saveTeachplanDto) {
        /* --- step0 通过课程计划的id判断是新增还是修改 --- */
        Long teachplanId = saveTeachplanDto.getId();
        if(teachplanId == null){
            //新增
            Teachplan teachplan = new Teachplan();
            BeanUtils.copyProperties(saveTeachplanDto,teachplan);
            //确定排序字段，找到它的同级节点个数，排序字段就是个数加1
            // select count(1) from teachplan where course_id=117 and parentid=268
            Long parentid = saveTeachplanDto.getParentid();
            Long courseId = saveTeachplanDto.getCourseId();
            int teachplanCount = getTeachplanCount(courseId, parentid);
            teachplan.setOrderby(teachplanCount);
            teachplanMapper.insert(teachplan);
        }else{
            //修改
            Teachplan teachplan = teachplanMapper.selectById(teachplanId);
            //将参数复制到teachplan
            BeanUtils.copyProperties(saveTeachplanDto,teachplan);
            teachplanMapper.updateById(teachplan);
        }
    }

    private int getTeachplanCount(Long courseId,Long parentId){
        LambdaQueryWrapper<Teachplan> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper = queryWrapper.eq(Teachplan::getCourseId, courseId).eq(Teachplan::getParentid, parentId);
        Integer count = teachplanMapper.selectCount(queryWrapper);
        return  count+1;
    }
    /**
     * 删除课程计划的接口
     * @param teachplanId
     */
    @Override
    public void deleteTeachplan(Long teachplanId){
        if(teachplanId == null) XueChengPlusException.cast("课程计划为空");
        /* ----- step1.判断当前要删除的课程计划是章还是节 ----- */
        Teachplan teachplan = teachplanMapper.selectById(teachplanId);
        //判断当前是章还是节
        int grade = teachplan.getGrade();
        /* ----- step2.利用grade属性可以判断是章还是节，方便进入后续处理 ------ */
        if(grade == 1){
            //当前计划为章，查询底下是否有节
            // select * from teachplan where parentid = {当前章计划id}
            LambdaQueryWrapper<Teachplan> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(Teachplan::getParentid,teachplanId);

            //获取查询的条目数
            int count = teachplanMapper.selectCount(queryWrapper);
            if(count > 0) XueChengPlusException.cast("课程计划还有子级信息，无法操作");
            /* ----- step3.删除计划 ----- */
            teachplanMapper.deleteById(teachplanId);
        }else{
            //当前计划为节，可以直接删除
            teachplanMapper.deleteById(teachplanId);
            /* ----- step3.当前节下的资源也要删除 ----- */
            LambdaQueryWrapper<TeachplanMedia> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(TeachplanMedia::getTeachplanId,teachplanId);
            teachplanMediaMapper.delete(queryWrapper);
        }

    }
    /**
     * 将课程计划下移
     * @param teachplanId
     */
    @Transactional
    @Override
    public void movedownTeachplan(Long teachplanId){
        swapTeachplan(teachplanId,1);
    }
    /**
     * 将课程计划上移
     * @param teachplanId
     */
    @Transactional
    @Override
    public void moveupTeachplan(Long teachplanId){
        swapTeachplan(teachplanId,-1);
    }

    /**
     * 交换课程计划
     * @param id 课程计划id
     * @param type 交换类型
     */
    @Transactional
    public void swapTeachplan(Long id,Integer type){
        /* ----- step1. 拿到当前的课程计划，以及课程计划的顺序
                        获取要更改位置的计划顺序 ----- */
        Teachplan teachplan = teachplanMapper.selectById(id);
        Integer orderBy = teachplan.getOrderby();

        Integer orderByNew = orderBy + type;
        //获取要更改的位置 的 父节点、课程id
        LambdaQueryWrapper<Teachplan> qw = new LambdaQueryWrapper<>();
        qw.eq(Teachplan::getParentid,teachplan.getParentid())
                .eq(Teachplan::getOrderby,orderByNew)
                .eq(Teachplan::getCourseId,teachplan.getCourseId());
        //定位找到
        Teachplan teachplanNext = teachplanMapper.selectOne(qw);
        /* ----- step2.交换排序字段 -----*/
        teachplan.setOrderby(orderByNew);
        teachplanNext.setOrderby(orderBy);

        teachplanMapper.updateById(teachplan);
        teachplanMapper.updateById(teachplanNext);
    }

    /**
     * 绑定媒资
     * @param bindTeachplanMediaDto
     */
    @Transactional
    @Override
    public void associationMedia(BindTeachplanMediaDto bindTeachplanMediaDto){
        //课程计划id
        Long teachplanId = bindTeachplanMediaDto.getTeachplanId();
        Teachplan teachplan = teachplanMapper.selectById(teachplanId);
        if(teachplan == null){
            XueChengPlusException.cast("课程计划不存在");
        }

        //先删除原有记录,根据课程计划id删除它所绑定的媒资
        int delete = teachplanMediaMapper.delete(new LambdaQueryWrapper<TeachplanMedia>().eq(TeachplanMedia::getTeachplanId, bindTeachplanMediaDto.getTeachplanId()));

        //再添加新记录
        TeachplanMedia teachplanMedia = new TeachplanMedia();
        BeanUtils.copyProperties(bindTeachplanMediaDto,teachplanMedia);
        teachplanMedia.setCourseId(teachplan.getCourseId());
        teachplanMedia.setMediaFilename(bindTeachplanMediaDto.getFileName());
        teachplanMediaMapper.insert(teachplanMedia);

    }
}
