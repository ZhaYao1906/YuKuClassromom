package com.xuecheng.content.feignclient;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * @author Mr.M
 * @version 1.0
 * @description TODO
 * @date 2023/2/22 11:06
 */
public class MediaServiceClientFallback implements MediaServiceClient{
 @Override
 //继承了MediaServiceClient，重写了upload,当发生熔断，执行这个upload
 public String upload(MultipartFile filedata, String objectName) throws IOException {
  return null;//但是这种方法的问题就是无法拿到熔断的异常
 }
}
