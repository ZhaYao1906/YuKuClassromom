package com.xuecheng.content.model.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description 修改课程DTO
 */
//修改比新增就多了一个id属性，所以可以直接继承AddCourseDto
@Data
public class EditCourseDto extends AddCourseDto {

 @ApiModelProperty(value = "课程id", required = true)//swagger文档需要这个注解
 private Long id;

}
